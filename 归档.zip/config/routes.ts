export default [
  { path: '/user', layout: false, routes: [{ path: '/user/login', component: './User/Login' }] },
  //{ name: 'Welcome', path: '/welcome', icon: 'smile', component: './Welcome' },

  {
    path: '/account-statis',
    name: '数据统计',
    icon: 'crown',
    routes: [
      { name: '自有账号统计', path: 'self-account', component: './AccountStatis/SelfAccount' },
      { name: '第三方账号统计', path: 'third-account', component: './AccountStatis/ThirdAccount' },
    ],
  },
  {
    path: '/gpt-generator',
    name: 'GPT 小工具',
    icon: 'crown',
    routes: [
      { name: 'GPT 推文库', path: 'tweet-library', component: './GptGenerator/TweetLibrary' },
      { name: 'GPT 推文仿写', path: 'article-generator', component: './GptGenerator/ArticleGen' },
      { name: 'GPT 内容分段', path: 'content-split', component: './GptGenerator/ContentSplit' },
      { name: 'GPT 标题生成', path: 'title-generator', component: './GptGenerator/TitleGen' },
      { name: 'GPT 推文搜索', path: 'tweet-search', component: './GptGenerator/TweetSearch' },
    ],
  },
  {
    path: '/llm',
    name: 'LLM',
    icon: 'crown',
    routes: [{ name: 'LLM', path: 'llm', component: './FileUpload' }],
  },
  {
    path: '/entry-link',
    name: '入口链接',
    icon: 'crown',
    routes: [{ name: '入口链接', path: 'entry-link', component: './EntryLink' }],
  },
  //  {
  //    path: '/promotion',
  //    name: '小推手',
  //    icon: 'crown',
  //    routes:[
  //      { name: '推文推广', path: 'twitter-promotion', component: './Promotion/TwitterPromotion' },
  //      { name: '授权列表', path: 'authorization-list', component: './Promotion/AuthorizationList' },
  //    ],
  // },

  // {
  //   path: '/account-statis',
  //   name: '数据统计',
  //   icon: 'crown',
  //   routes: [
  //     {
  //       path: '/account-statis/self-account',
  //       name: '自有账号统计',
  //       component: '/AccountStatis/SelfAccount',
  //     },
  //     // {
  //     //   path: '/account-statis/thirdAccount',
  //     //   name: '第三方账号统计',
  //     //   component: '/AccountStatis/thirdAccount',
  //     // },
  //   ],
  // },

  { path: '/', redirect: '/account-statis/third-account' },
  { path: '*', layout: false, component: './404' },
];
