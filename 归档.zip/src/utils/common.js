/**
 * json 对象 转 formData
 */
export const json2formatData = (data) => {
  const formData = new FormData();
  Object.entries(data).forEach((k, v) => formData.append(k, v));
  return formData;
};

export const IS_LOCAL = process.env.NODE_ENV === 'development';
