import React from 'react'

import { Button } from 'antd'
import styles from './index.less';

type UserCompProps = {
    name?: string;
    profileImageUrl?: string;
    userAccount?: string;
}

const UserComp = (props: UserCompProps) => {
    const {name, profileImageUrl, userAccount} = props;
    return (
        <div className={styles.nameBox}>
            <img src={profileImageUrl} alt="" />
            <div className={styles.rightBox}>
                <div>{name}</div>
                <Button
                    rel="noreferrer"
                    href= {`https://mobile.twitter.com/${userAccount}`}
                    target= '_blank'
                    type="link"
                    size="small"
                    // onClick={
                    //     () => {
                    //         window.open(`https://mobile.twitter.com/${user_account}`, '_blank')
                    //     }
                    // }
                >
                    @{userAccount}
                </Button>
            </div>
        </div>
    )
}


export default UserComp