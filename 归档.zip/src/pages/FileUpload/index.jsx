import { Upload, message, Button } from 'antd';
import { useState, useEffect } from 'react';
import { PageContainer } from '@ant-design/pro-components';
import { InboxOutlined } from '@ant-design/icons';

import { fileUpload } from '@/services/ant-design-pro/api';

import classNames from 'classnames/bind';
import styles from './index.less';
const cx = classNames.bind(styles);

const { Dragger } = Upload;

const props = {
  name: 'file',
  multiple: false,
  action: 'https://twitterresearchapi.visioncap.io/security/admin/uploadfile',
  beforeUpload: (file) => {
    const isMd = file.type === 'text/markdown';
    const fileExt = file.name.split('.').pop() === 'md';

    console.log(fileExt, file.name.split('.').pop(), file);
    if (!fileExt) {
      message.error('只能上传markdown文件!');
    }
    return isMd;
  },
  onChange(info) {
    const { status } = info.file;
    if (status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (status === 'done') {
      message.success(`${info.file.name} 文件上传成功！`);
    } else if (status === 'error') {
      message.error(`${info.file.name} 文件上传失败！`);
    }
  },
};

const handleFileUpload = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('login_token', localStorage.getItem('login_token'));

  try {
    const response = await fileUpload(formData);
    console.log(response);
  } catch (error) {
    console.error(error);
  }
};

const FileUpload = () => {
  return (
    <PageContainer header={{ style: { backgroundColor: 'white', height: '90px' } }}>
      <div className={cx('container')}>
        <div className={cx('box')}>
          <div className={cx('button')}>
            <Button type="primary" onClick={() => {}}>
              生成
            </Button>
          </div>
          <Dragger {...props} onChange={({ file }) => handleFileUpload(file)}>
            <p className="ant-upload-drag-icon">
              <InboxOutlined />
            </p>
            <p className="ant-upload-text">点击或拖拽上传 Markdown 文件</p>
            <p className="ant-upload-hint">只能上传 Markdown 文件</p>
          </Dragger>
        </div>
      </div>
    </PageContainer>
  );
};

export default FileUpload;
