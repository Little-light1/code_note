import { Table } from 'antd';
import classNames from 'classnames/bind';
import styles from './index.less';
const cx = classNames.bind(styles);

const EntryLink = () => {
  const dataSource = [];

  const columns = [
    {
      title: '名称',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: '正式',
      dataIndex: 'formal',
      key: 'formal',
      render: (formal) => {
        return (
          <a href={formal} target="blank">
            {formal}
          </a>
        );
      },
    },
    {
      title: '测试',
      dataIndex: 'test',
      key: 'test',
      render: (test) => {
        return (
          <a href={test} target="blank">
            {test}
          </a>
        );
      },
    },
    {
      title: '预览',
      dataIndex: 'preview',
      key: 'preview',
      render: (preview) => {
        return (
          <a href={preview} target="blank">
            {preview}
          </a>
        );
      },
    },
    // {
    //   title: '操作',
    //   key: 'action',
    //   render: () => {
    //     return <Button size="small">修改</Button>;
    //   },
    // },
  ];

  return (
    <div className="area">
      <Table dataSource={dataSource} columns={columns} pagination={false} />
    </div>
  );
};

export default EntryLink;
