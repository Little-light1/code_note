export default function PopularTweet() {
  return <div>PopularTweet</div>;
}
