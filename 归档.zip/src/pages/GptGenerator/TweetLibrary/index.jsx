import { getTweetList } from '@/services/ant-design-pro/api';
import { EditOutlined } from '@ant-design/icons';
import { PageContainer } from '@ant-design/pro-components';
import { history } from '@umijs/max';
import { useRequest } from 'ahooks';

import {
  Avatar,
  Button,
  Card,
  Col,
  Form,
  Input,
  InputNumber,
  List,
  Modal,
  Radio,
  Row,
  Select,
  Space,
  Spin,
  Tooltip,
} from 'antd';
import classNames from 'classnames/bind';
import moment from 'moment';
import { useEffect, useState } from 'react';
import styles from './index.less';

const cx = classNames.bind(styles);

const TAB_DATA = [
  { label: '趋势分析', value: '趋势分析' },
  { label: '数据分析', value: '数据分析' },
  { label: '一图胜千言', value: '一图胜千言' },
  { label: 'GPT原创', value: 'GPT原创' },
  { label: '交易思考', value: '交易思考' },
  { label: '项目分析', value: '项目分析' },
  { label: '工具', value: '工具' },
  { label: '其他', value: '其他' },
];

const TweetLibrary = () => {
  const [spinning, setSpinning] = useState(false);
  const [category, setCategory] = useState('数据分析');
  const [dataList, setDataList] = useState([]);
  const [form] = Form.useForm();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const { TextArea } = Input;

  useEffect(() => {
    setSpinning(true);
    run({ query_mode: 1, category });
  }, []);

  const { run } = useRequest(
    (params) => {
      return getTweetList(params);
    },
    {
      manual: true, // 关闭自动执行
      onSuccess: ({ data }) => {
        setSpinning(false);
        setDataList(data.list);
      },
    },
  );

  const searchList = (type) => {
    setSpinning(true);
    const values = {};
    values.query_mode = 1;
    values.category = type.target.value;
    run({ ...values });
  };

  const fakeContent = () => {
    alert('仿写逻辑');
  };
  const onFinish = (values) => {
    setSpinning(true);
    values.query_mode = 1;
    values.category = category;
    if (!values.like_count) {
      delete values.like_count;
    }
    if (!values.retweet_count) {
      delete values.retweet_count;
    }
    if (!values.keywords) {
      delete values.keywords;
    }
    run({ ...values });
  };

  const randomFun = () => {
    setSpinning(true);
    form.validateFields().then((values) => {
      values.query_mode = 2;
      values.category = category;
      if (!values.like_count) {
        delete values.like_count;
      }
      if (!values.retweet_count) {
        delete values.retweet_count;
      }
      if (!values.keywords) {
        delete values.keywords;
      }
      run({ ...values });
    });
  };

  const onPageChange = (page, pageSize) => {
    setSpinning(true);
    form.validateFields().then((values) => {
      if (!values.like_count) {
        delete values.like_count;
      }
      if (!values.retweet_count) {
        delete values.retweet_count;
      }
      if (!values.keywords) {
        delete values.keywords;
      }
      values.query_mode = 1;
      values.page = page;
      values.limit = pageSize;
      values.category = category;
      run({ ...values });
    });
  };

  const splitJump = (val) => {
    localStorage.setItem('content', val);
    history.push('/gpt-generator/article-generator');
  };

  return (
    <PageContainer header={{ style: { backgroundColor: 'white', height: '90px' } }}>
      <Spin spinning={spinning} style={{ width: '100%' }}>
        <Card style={{ marginBottom: '20px', width: '100%' }}>
          <Space direction="vertical" align="start" size="large">
            <Radio.Group
              defaultValue={'数据分析'}
              options={TAB_DATA}
              optionType="button"
              buttonStyle="solid"
              onChange={(type) => {
                searchList(type);
                setCategory(type.target.value);
              }}
            />
            <Form layout="inline" form={form} onFinish={onFinish}>
              <Form.Item label="点赞数量" name="like_count" initialValue={''}>
                <InputNumber min={0} precision={0} style={{ width: '100px' }} />
              </Form.Item>
              <Form.Item label="转发数量" name="retweet_count" initialValue={''}>
                <InputNumber min={0} precision={0} />
              </Form.Item>
              <Form.Item label="关键词汇" name="keywords" initialValue={''}>
                <Input />
              </Form.Item>
              <Form.Item>
                <Button htmlType="submit">筛选</Button>
              </Form.Item>
              <Form.Item>
                <Button
                  onClick={() => {
                    randomFun();
                  }}
                >
                  随机推荐
                </Button>
              </Form.Item>
              <Form.Item>
                <Button
                  onClick={() => {
                    setIsModalOpen(true);
                  }}
                >
                  添加账户
                </Button>
              </Form.Item>
            </Form>
          </Space>
        </Card>
        <List
          grid={{
            gutter: 16,
            column: 4,
          }}
          pagination={{
            onChange: (page, pageSize) => {
              onPageChange(page, pageSize);
            },
            defaultCurrent: 1,
            pageSize: 20,
            showSizeChanger: false,
          }}
          dataSource={dataList}
          renderItem={(item) => (
            <List.Item>
              <Card
                hoverable
                bodyStyle={{ paddingBottom: 20 }}
                actions={[
                  <div key="like">
                    <span>点赞数量: {item.like_count}</span>
                  </div>,
                  <div key="retweet">
                    <span>转发数量: {item.retweet_count}</span>
                  </div>,
                  <Tooltip title="仿写" key="仿写">
                    <EditOutlined
                      onClick={() => {
                        splitJump(item.content.replace(/\\n/g, '\n'));
                      }}
                    />
                  </Tooltip>,
                ]}
              >
                <Card.Meta
                  avatar={<Avatar size="small" src={item.avatar} />}
                  title={moment(item.created_at).format('YYYY-MM-DD')}
                  description={
                    <div className={styles.cardInfo}>
                      <p className={styles.cardContent}>{item.content}</p>
                    </div>
                  }
                  className={cx('card-body')}
                />

                {/* <div className={styles.cardInfo}>
                <p className={styles.cardContent}>{item.content.replace(/\\n/g, '\n')}</p>
              </div> */}
              </Card>
            </List.Item>
          )}
        />
        <Modal
          open={isModalOpen}
          onCancel={handleCancel}
          footer={null}
          // title="推文添加"
          width={650}
          bodyStyle={{ padding: '10px' }}
          // className={cx('modal1')}
        >
          <div className={cx('modal-title')}>推文添加</div>
          <Form labelAlign="right">
            <Form.Item label="链接：" name="link" initialValue={''}>
              <Input style={{ width: 550 }} />
            </Form.Item>
            <Row>
              <Col span={8}>
                <Form.Item label="点赞：" name="like" initialValue={''}>
                  <InputNumber style={{ width: 140 }} />
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item label="转发：" name="retweet" initialValue={''}>
                  <InputNumber style={{ width: 140 }} />
                </Form.Item>
              </Col>
            </Row>
            <Form.Item label="分类" name="select" initialValue={''}>
              <Select options={TAB_DATA} size="middle" style={{ width: 140 }} />
            </Form.Item>
            <Row justify="center">
              <Col>
                <Button htmlType="submit" type="primary">
                  提交推文
                </Button>
              </Col>
            </Row>
          </Form>
        </Modal>
      </Spin>
    </PageContainer>
  );
};

export default TweetLibrary;
