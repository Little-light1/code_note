import { PageContainer } from "@ant-design/pro-components";
import type { RadioChangeEvent } from "antd";
import { Button, Checkbox, DatePicker, Form, Input, Radio, Row } from "antd";
import dayjs, { Dayjs } from "dayjs";
import { useState } from "react";

const contains = [
  "AI",
  "ChatGpt",
  "BTC",
  "效率",
  "工具",
  "ETH",
  "Token",
  "Tools",
  "投资",
  "Github",
];
const exclude = ["Giveaway", "抽奖", "airdrop"];
const language = [
  { label: "中文", value: "zh" },
  { label: "英文", value: "en" },
];

export default function TweetSearch() {
  const tweetUrl = "https://twitter.com/search?q=";
  const [form] = Form.useForm();
  const onFinish = () => {
    const currentUrl = window.location.origin;
    const targetUrl = tweetUrl + form.getFieldValue("params");
    // currentUrl + "/" +

    window.open(targetUrl, "_blank");
  };
  const onChange = (e: any) => {
    console.log(e, "e");
  };
  const [faveValue, setFaveValue] = useState(0);
  const [replyValue, setReplyValue] = useState(0);
  const [retweetValue, setRetweetValue] = useState(0);
  const [dateValue, setDateValue] = useState();
  const [dateArrValue, setDateArrValue] = useState<Dayjs | undefined>();
  const [curParams, setCurParams] = useState("");
  const [curDate, setCurDate] = useState("");

  const { RangePicker } = DatePicker;

  const onFaveChange = (e: RadioChangeEvent) => {
    console.log("radio checked", e.target.value);
    setFaveValue(e.target.value);
  };
  const onReplyChange = (e: RadioChangeEvent) => {
    setReplyValue(e.target.value);
  };
  const onRetweetChange = (e: RadioChangeEvent) => {
    setRetweetValue(e.target.value);
  };
  const onDateChange = (e: RadioChangeEvent) => {
    setDateValue(e.target.value);
    setDateArrValue(undefined);
    console.log(e, "e");
    let str: string = curParams;
    let date1 =
        " since:" +
        dayjs().subtract(e.target.value, "days").format("YYYY-MM-DD"),
      date2 = " until:" + dayjs().format("YYYY-MM-DD");
    str += date1;
    str += date2;
    form.setFieldValue("params", str);
    setCurDate(date1 + " until:" + date2);
  };
  const onDatePikerChange = (date: Dayjs, dateString: string) => {
    setDateValue(undefined);
    setDateArrValue(date);
    console.log(date, dateString);
    let str: string = curParams;
    if (date) {
      str += " since:" + [dateString[0]];
      str += " until:" + [dateString[1]];
    }
    form.setFieldValue("params", str);
    setCurDate(" since:" + [dateString[0]] + " until:" + [dateString[1]]);
  };
  const onValuesChange = (val: any, all: { [name: string]: any }) => {
    console.log(val, all, "val, all");

    if (val.params) return;
    let str: string = "";
    if (all.contain?.length) {
      all.contain = all.contain.map((ele: string) => `"${ele}"`);
      str += " (" + all.contain.join(" OR ") + ")";
    }
    if (all.except?.length) {
      all.except = all.except.map((ele: string) => `"${ele}"`);
      str += " -" + all.except.join(" -");
    }
    if (all.min_faves) {
      str += " min_faves:" + all.min_faves;
    }
    if (all.min_replies) {
      str += " min_replies:" + all.min_replies;
    }
    if (all.min_retweets) {
      str += " min_retweets:" + all.min_retweets;
    }
    if (all.lan?.length) {
      all.lan = all.lan.map((ele: string) => `lang:${ele}`);
      str += " (" + all.lan.join(" OR ") + ")";
    }
    if (all.account?.length) {
      all.account = all.account.split(" ").map((ele: string) => `from:${ele}`);
      str += " (" + all.account.join(" OR ") + ")";
    }
    setCurParams(str);

    curDate && (str += curDate);
    console.log(str);
    form.setFieldValue("params", str);
  };

  const { TextArea } = Input;
  return (
    <PageContainer
      header={{ style: { backgroundColor: "white", height: "90px" } }}
    >
      <div>
        <Form
          onFinish={onFinish}
          form={form}
          labelAlign="right"
          onValuesChange={onValuesChange}
        >
          <Form.Item name="params">
            <TextArea rows={6}></TextArea>
          </Form.Item>
          <Form.Item label="包含词语" name="contain">
            <Checkbox.Group options={contains} onChange={onChange}>
              <Checkbox></Checkbox>
            </Checkbox.Group>
          </Form.Item>
          <Form.Item label="排除词语" name="except">
            <Checkbox.Group options={exclude} onChange={onChange}>
              <Checkbox></Checkbox>
            </Checkbox.Group>
          </Form.Item>
          <Form.Item label="语言选项" name="lan">
            <Checkbox.Group options={language} onChange={onChange}>
              <Checkbox></Checkbox>
            </Checkbox.Group>
          </Form.Item>
          <Form.Item label="最少点赞" name="min_faves">
            <Radio.Group onChange={onFaveChange} value={faveValue}>
              <Radio value={50}>50</Radio>
              <Radio value={100}>100</Radio>
              <Radio value={200}>200</Radio>
              <Radio value={500}>500</Radio>
              <Radio value={1000}>1000</Radio>
            </Radio.Group>
          </Form.Item>
          <Form.Item label="最少回复" name="min_replies">
            <Radio.Group onChange={onReplyChange} value={replyValue}>
              <Radio value={50}>50</Radio>
              <Radio value={100}>100</Radio>
              <Radio value={200}>200</Radio>
              <Radio value={500}>500</Radio>
              <Radio value={1000}>1000</Radio>
            </Radio.Group>
          </Form.Item>
          <Form.Item label="最少转发" name="min_retweets">
            <Radio.Group onChange={onRetweetChange} value={retweetValue}>
              <Radio value={50}>50</Radio>
              <Radio value={100}>100</Radio>
              <Radio value={200}>200</Radio>
              <Radio value={500}>500</Radio>
              <Radio value={1000}>1000</Radio>
            </Radio.Group>
          </Form.Item>
          <Form.Item label="发布时间">
            <Radio.Group onChange={onDateChange} value={dateValue}>
              <Radio value={1}>24小时</Radio>
              <Radio value={3}>近3天</Radio>
              <Radio value={7}>近7天</Radio>
              <Radio value={30}>近30天</Radio>
              <Radio value={90}>近90天</Radio>
              <RangePicker onChange={onDatePikerChange} value={dateArrValue} />
            </Radio.Group>
          </Form.Item>
          <Form.Item label="指定账号" name="account">
            <TextArea rows={2}></TextArea>
          </Form.Item>
          <Row justify="center">
            <Form.Item>
              <Button htmlType="submit" type="primary">
                搜索
              </Button>
            </Form.Item>
          </Row>
        </Form>
      </div>
    </PageContainer>
  );
}
