import { getContentFromChatgpt } from '@/services/ant-design-pro/api';
import { PageContainer } from '@ant-design/pro-components';

import { useRequest } from 'ahooks';
import { useEffect, useState } from 'react';

import { Button, Form, Input, message } from 'antd';
import classNames from 'classnames/bind';
import styles from './index.less';

const cx = classNames.bind(styles);

const ContentSplit = () => {
  const [roleName, setRoleName] = useState('');

  const [templateName, setTemplateName] = useState('');
  const [gptValue, setGptValue] = useState('');
  const [gptData, setGptData] = useState({});
  const [gptResults, setGptResults] = useState(['内容1', '内容2', '内容3']);
  const [form] = Form.useForm();

  const { TextArea } = Input;

  const copyToClipboard = async (string) => {
    await navigator.clipboard.writeText(string);
    try {
      message.success('Copy Success');
    } catch (error) {
      message.error('Copy Failed');
    }
  };
  const onFinish = (values) => {
    const { role, templateSection, content } = values;

    localStorage.setItem('role', role); // 保存角色输入到本地存储中
    localStorage.setItem('templateSection', templateSection); // 保存标题模板输入到本地存储中
    run({ role, content: templateSection + content });
  };

  useEffect(() => {
    form.setFieldsValue({
      role: roleName,
      templateSection: templateName,
    });
  }, [form, roleName, templateName]);

  useEffect(() => {
    const storedRole = localStorage.getItem('role');
    const storedTemplate = localStorage.getItem('templateSection');
    const content = localStorage.getItem('content') || '';
    form.setFieldValue('content', content);

    if (storedRole) {
      setRoleName(storedRole);
    }
    if (storedTemplate) {
      setTemplateName(storedTemplate);
    }
  }, []);

  const { data, loading, run } = useRequest(
    (params) => {
      return getContentFromChatgpt(params);
    },
    {
      manual: true, // 关闭自动执行
      onSuccess: (data) => {
        // setGptValue(data.data.result); // 更新GPT结果状态
        if (data && data.code === 200) {
          let list = data?.data?.result ? JSON.parse(data.data.result) : '';

          if (Array.isArray(list)) {
            const results = list?.map((item) => {
              let val = Object.values(item)[0];
              const content = val?.replace(/^\d+\/\s*/, ''); // 去掉开头的数字和斜杠
              return content;
            });
            setGptResults(results);
            // console.log(results);
          }
        }
        if (data && data.code !== 200) {
          message.error(data?.msg);
        }
      },
    },
  );
  return (
    <PageContainer header={{ style: { backgroundColor: 'white', height: '90px' } }}>
      <div className={cx('container')}>
        <div className={cx('box')}>
          <Form onFinish={onFinish} form={form} labelAlign="right" labelCol={{ span: 3 }}>
            <Form.Item name="content" label="待处理内容">
              <TextArea rows={10} />
            </Form.Item>
            <Form.Item name="role" label="角色输入">
              <TextArea rows={2} />
            </Form.Item>
            <Form.Item name="templateSection" label="GPT 提示词">
              <TextArea rows={6} />
            </Form.Item>
            {gptResults.map((result, index) => (
              <Form.Item key={index} name={`gpt${index + 1}`} label={`GPT结果 ${index + 1}`}>
                <div style={textStyle}>
                  <TextArea
                    rows={6}
                    value={result}
                    onChange={(e) => {
                      const newGptResults = [...gptResults];
                      newGptResults[index] = e.target.value;
                      setGptResults(newGptResults);
                    }}
                  />
                  <Button
                    onClick={() => {
                      copyToClipboard(result);
                    }}
                  >
                    复制本条
                  </Button>
                </div>
              </Form.Item>
            ))}

            <div className={cx('button')}>
              <Button type="primary" htmlType="submit" loading={loading}>
                一键分段
              </Button>
            </div>
          </Form>
        </div>
      </div>
    </PageContainer>
  );
};

export default ContentSplit;

const textStyle = { display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 12 };
