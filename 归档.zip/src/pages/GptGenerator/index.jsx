import { useState, useEffect } from 'react';
import { PageContainer } from '@ant-design/pro-components';
import classNames from 'classnames/bind';

import { message } from 'antd';

import styles from './index.less';

import { getContentFromChatgpt } from '@/services/ant-design-pro/api';
import { useRequest } from 'ahooks';
import { Button, Form, Input } from 'antd';
//import clipboard from 'clipboard';

const cx = classNames.bind(styles);

const GptGenerator = () => {
  // const roleEdit = '你是一个工程师';
  // const titleEdit = '不会吧，还有人不知道';

  const [form] = Form.useForm();

  const { TextArea } = Input;

  const [gptResult, setGptResult] = useState('');

  const [roleName, setRoleName] = useState('');

  const [titleName, setTitleName] = useState('');

  useEffect(() => {
    form.setFieldsValue({
      role: roleName,
      title: titleName,
    });
  }, [form, roleName, titleName]);

  useEffect(() => {
    const storedRole = localStorage.getItem('role');
    const storedTitle = localStorage.getItem('title');
    if (storedRole) {
      setRoleName(storedRole);
    }
    if (storedTitle) {
      setTitleName(storedTitle);
    }
  }, []);

  const { data, loading, run } = useRequest(
    (params) => {
      return getContentFromChatgpt(params);
    },
    {
      manual: true, // 关闭自动执行
      onSuccess: (data) => {
        setGptResult(data.data.result); // 更新GPT结果状态
        form.setFieldValue('gpt', data.data.result); // 将GPT结果放到表单中
      },
    },
  );

  const copyToClipboard = async (string) => {
    await navigator.clipboard.writeText(string);
    try {
      message.success('Copy Success');
    } catch (error) {
      message.error('Copy Failed');
    }
  };

  const onFinish = (values) => {
    const { role, title, content } = values;

    localStorage.setItem('role', role); // 保存角色输入到本地存储中
    localStorage.setItem('title', title); // 保存标题模板输入到本地存储中
    //console.log(values);
    run({ role, content: title + content });
    if (data && data.code === 200) {
      form.setFieldValue('gpt', data.data.result);
    }
    if (data && data.code !== 200) {
      message.error(data?.msg);
    }
  };

  return (
    <PageContainer header={{ style: { backgroundColor: 'white', height: '90px' } }}>
      <div className={cx('container')}>
        <div className={cx('box')}>
          <Form onFinish={onFinish} form={form}>
            <Form.Item
              name="role"
              label="角色输入"
              initialValue={roleName}
              //onValueChange={(e) => setRoleName(e.target.value)}
            >
              <TextArea rows={5} />
            </Form.Item>
            <Form.Item name="title" label="标题模板" initialValue={titleName}>
              <TextArea rows={5} />
            </Form.Item>
            <Form.Item name="content" label="文本输入">
              <TextArea rows={5} />
            </Form.Item>
            <Form.Item name="gpt" label="GPT结果" readOnly>
              <TextArea rows={7} value={gptResult} />
            </Form.Item>
            <div className={cx('button')}>
              <Button type="primary" htmlType="submit" loading={loading}>
                一键生成
              </Button>
              <Button
                type="primary"
                onClick={() => {
                  copyToClipboard(form.getFieldValue('gpt'));
                }}
              >
                一键复制
              </Button>
            </div>
          </Form>
        </div>
      </div>
    </PageContainer>
  );
};

export default GptGenerator;
