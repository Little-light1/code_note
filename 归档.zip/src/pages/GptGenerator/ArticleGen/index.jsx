import { getContentFromChatgpt } from '@/services/ant-design-pro/api';
import { PageContainer } from '@ant-design/pro-components';
import { history } from '@umijs/max';
import { useRequest } from 'ahooks';
import { Button, Form, Input, message, Modal, Radio } from 'antd';
import classNames from 'classnames/bind';
import { useCallback, useEffect, useState } from 'react';
import styles from './index.less';

const cx = classNames.bind(styles);
const translate =
  '你是一家中文区块链和 Web3 领域的推特KOL的翻译助手一步一步的来思考 1.把内容翻译成中文，不做延展，专有名词不翻译 2.注意联系上下文,注意准确地解释区块链和数字货币领域相关术语3.你的翻译成果应该接近于中文为母语的人';

const ArticleGenerator = () => {
  const [tweetPreview, setTweetPreview] = useState('');
  const [twitterLink, setTwitterLink] = useState('');

  const [form] = Form.useForm();
  const [roleName, setRoleName] = useState('');

  const [templateName, setTemplateName] = useState('');
  const [gpt1Value, setGpt1Value] = useState('');
  const [gpt2Value, setGpt2Value] = useState('');
  const [gpt3Value, setGpt3Value] = useState('');
  const [gptResults, setGptResults] = useState(['内容1', '内容2', '内容3']);

  useEffect(() => {
    const content2 = localStorage.getItem('content') || '';
    setTweetPreview(content2);
  }, []);

  const copyToClipboard = async (string) => {
    await navigator.clipboard.writeText(string);
    try {
      message.success('Copy Success');
    } catch (error) {
      message.error('Copy Failed');
    }
  };

  useEffect(() => {
    form.setFieldsValue({
      link: twitterLink,
      role: roleName,
      template: templateName,
    });
  }, [form, roleName, templateName, twitterLink]);

  useEffect(() => {
    const storedRole = localStorage.getItem('role');
    const storedTemplate = localStorage.getItem('template');
    if (storedRole) {
      setRoleName(storedRole);
    }
    if (storedTemplate) {
      setTemplateName(storedTemplate);
    }
  }, []);

  const { TextArea } = Input;

  const onFinish = async (values) => {
    const { role, template, content } = values;

    localStorage.setItem('role', role); // 保存角色输入到本地存储中
    localStorage.setItem('template', template); // 保存标题模板输入到本地存储中

    const modifiedContent = form.getFieldValue('translate')
      ? translate + template + tweetPreview
      : template + tweetPreview;
    try {
      await Promise.all([
        runGpt1({ role, content: modifiedContent }),
        runGpt2({ role, content: modifiedContent }),
        runGpt3({ role, content: modifiedContent }),
      ]);
    } catch (error) {
      message.error('Error occurred while fetching GPT results');
    }
  };

  const {
    data: gpt1Data,
    loading: gpt1Loading,
    run: runGpt1,
  } = useRequest(
    (params) => {
      return getContentFromChatgpt(params);
    },
    {
      manual: true,
      onSuccess: (data) => {
        setGpt1Value(data.data.result);
        form.setFieldValue('gpt1', data.data.result);
      },
    },
  );

  const {
    data: gpt2Data,
    loading: gpt2Loading,
    run: runGpt2,
  } = useRequest(
    (params) => {
      return getContentFromChatgpt(params);
    },
    {
      manual: true,
      onSuccess: (data) => {
        setGpt2Value(data.data.result);
        form.setFieldValue('gpt2', data.data.result);
      },
    },
  );

  const {
    data: gpt3Data,
    loading: gpt3Loading,
    run: runGpt3,
  } = useRequest(
    (params) => {
      return getContentFromChatgpt(params);
    },
    {
      manual: true,
      onSuccess: (data) => {
        setGpt3Value(data.data.result);
        form.setFieldValue('gpt3', data.data.result);
      },
    },
  );

  //   'https://rsshub-railway-main-1wvj81.beboldcap.com/twitter/tweet/bitmax_eth/status/1668912153187995650',
  const fetchLink = 'https://rsshub-railway-main-1wvj81.beboldcap.com/twitter/tweet/';

  const fetchData = useCallback(async (fullLink) => {
    const value = await fetch(fullLink)
      .then((response) => response.text())
      .then((data) => {
        let parser = new DOMParser();
        let xml = parser.parseFromString(data, 'text/xml');

        // 获取URL，并从URL中提取作者名

        const author = url.split('/')[5];

        let items = Array.from(xml.getElementsByTagName('item'));
        items.sort((a, b) => {
          let aId = a.querySelector('link').textContent.split('/').pop();
          let bId = b.querySelector('link').textContent.split('/').pop();
          return aId - bId;
        });

        // 筛选出符合条件的items
        const filteredItems = items.filter((item) => {
          const itemAuthor = item.querySelector('author').textContent.trim();
          const description = item.querySelector('description').textContent;

          // console.log('itemAuthor:' + itemAuthor);
          // console.log('description:' + description);
          return !description.startsWith('Re @');
        });
        // console.log('author:' + author);
        // console.log('filteredItems:' + filteredItems);
        // 获取description并移除HTML标签和开头的"Re "
        let descriptions = filteredItems.map((item) => {
          let description = item.querySelector('description').textContent;
          description = description.replace(/<[^>]*>/g, ''); // remove HTML tags
          description = description.replace(/^Re /, ''); // remove "Re " at the start of the description
          return description;
        });
        return descriptions.join('\n\n');
        // setTweetPreview(descriptions.join('\n\n'));
      });
    return value;
  }, []);
  const getTwitter = async () => {
    const twitterLinkValue = form.getFieldValue('link');
    setTwitterLink(twitterLinkValue);

    const tweetId = twitterLinkValue.split('https://twitter.com/')[1];
    const fullLink = fetchLink + tweetId;
    const value = await fetchData(fullLink);
    setTweetPreview(value);
  };

  const url =
    'https://rsshub-railway-main-1wvj81.beboldcap.com/twitter/tweet/0xUnicorn/status/1671073809204641792';

  const splitJump = (key, val) => {
    localStorage.setItem('content', val);
    history.push('/gpt-generator/content-split');
  };
  const [isModalOpen, setIsModalOpen] = useState(false);
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  return (
    <PageContainer header={{ style: { backgroundColor: 'white', height: '90px' } }}>
      <div className={cx('container')}>
        <div className={cx('box')}>
          <Form onFinish={onFinish} form={form} labelAlign="right" labelCol={{ span: 3 }}>
            <Form.Item name="link" label="Twitter 链接">
              <div style={textStyle}>
                <TextArea rows={2} onChange={(e) => form.setFieldValue('link', e.target.value)} />
                <Button onClick={getTwitter}>获取推文</Button>
              </div>
            </Form.Item>
            <Form.Item name="content" label="推文预览">
              <TextArea
                rows={8}
                value={tweetPreview}
                onChange={(e) => setTweetPreview(e.target.value)}
              />

              <Form.Item name="translate" valuePropName="checked" initialValue={false}>
                <Radio>翻译为中文</Radio>
              </Form.Item>
            </Form.Item>
            <Form.Item name="template" label="内容模板">
              <TextArea rows={4} />
            </Form.Item>
            <Form.Item label="风格模板" className="template">
              <div style={{ display: 'flex', gap: '10px' }}>
                <Button>更加自信【号召力】</Button>
                <Button>更加正式【口语还】</Button>
                <Button>更加正式【官方】</Button>
                <Button>知乎风格【科普】</Button>
                <Button>小红书风格【可爱】</Button>
              </div>
            </Form.Item>
            <Form.Item label="高级模板" className="btn-list">
              <div style={{ display: 'flex', gap: '10px' }}>
                <Button>优化推文</Button>
                <Button>推文扩写</Button>
                <Button>添加表情符号</Button>
                <Button>缩短【精简】</Button>
              </div>
            </Form.Item>
            <Form.Item label="英文翻译">
              <Button>按照知乎风格翻译成中文</Button>
            </Form.Item>
            <div className={cx('button')}>
              <Button
                type="primary"
                htmlType="submit"
                loading={gpt1Loading || gpt2Loading || gpt3Loading}
              >
                一键生成
              </Button>
            </div>
            {/* <Form.Item name="role" label="角色输入">
              <TextArea rows={2} />
            </Form.Item> */}

            <Form.Item name="gpt1" label="GPT 结果 1">
              <div style={textStyle}>
                <TextArea rows={10} value={gpt1Value} />
                <div style={{ display: 'flex', gap: 16 }}>
                  <Button
                    onClick={() => {
                      copyToClipboard(form.getFieldValue('gpt1'));
                    }}
                  >
                    一键复制
                  </Button>
                  <Button
                    onClick={() => {
                      // splitJump('gpt1', gpt1Value);
                      setIsModalOpen(true);
                    }}
                  >
                    一键分段
                  </Button>
                </div>
              </div>
            </Form.Item>
            {/* <Form.Item name="gpt2" label="GPT 结果 2">
              <div style={textStyle}>
                <TextArea rows={4} value={gpt2Value} />
                <div style={{ display: 'flex', gap: 16 }}>
                  <Button
                    onClick={() => {
                      copyToClipboard(form.getFieldValue('gpt2'));
                    }}
                  >
                    一键复制
                  </Button>
                  <Button onClick={() => splitJump('gpt2', gpt2Value)}>一键分段</Button>
                </div>
              </div>
            </Form.Item>
            <Form.Item name="gpt3" label="GPT 结果 3">
              <div style={textStyle}>
                <TextArea rows={4} value={gpt3Value} />
                <div style={{ display: 'flex', gap: 16 }}>
                  <Button
                    onClick={() => {
                      copyToClipboard(form.getFieldValue('gpt3'));
                    }}
                  >
                    一键复制
                  </Button>
                  <Button onClick={() => splitJump('gpt3', gpt3Value)}>一键分段</Button>
                </div>
              </div>
            </Form.Item> */}
            {/* <div className={cx('button')}>
              <Button
                type="primary"
                htmlType="submit"
                loading={gpt1Loading || gpt2Loading || gpt3Loading}
              >
                一键生成
              </Button>
            </div> */}
          </Form>
          <Modal
            open={isModalOpen}
            onCancel={handleCancel}
            footer={null}
            title={<Title />}
            width={1000}
            className={cx('modal1')}
          >
            {/* <div style={{}}>内容分段</div> */}
            {gptResults.map((result, index) => (
              <Form.Item key={index} name={`gpt${index + 1}`} label={`GPT结果 ${index + 1}`}>
                <div style={textSplitStyle}>
                  <TextArea
                    rows={7}
                    value={result}
                    onChange={(e) => {
                      const newGptResults = [...gptResults];
                      newGptResults[index] = e.target.value;
                      setGptResults(newGptResults);
                    }}
                  />
                  <Button
                    onClick={() => {
                      copyToClipboard(result);
                    }}
                  >
                    复制本条
                  </Button>
                </div>
              </Form.Item>
            ))}
          </Modal>
        </div>
      </div>
    </PageContainer>
  );
};

export default ArticleGenerator;

const textStyle = {
  display: 'flex',
  flexDirection: 'column',
  gap: 12,
  alignItems: 'flex-end',
};
const textSplitStyle = {
  display: 'flex',
  gap: 12,
  alignItems: 'flex-start',
};

const Title = () => {
  return <div className={cx('modal-title')}>内容分段</div>;
};
