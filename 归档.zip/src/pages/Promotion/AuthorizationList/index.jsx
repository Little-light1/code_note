import { ProTable, PageContainer } from '@ant-design/pro-components';
import { Button, Modal, Divider, Checkbox, Row, message, Form } from 'antd';
import { getaccountlist, jumpoauthpage } from '@/services/ant-design-pro/api';

//import { } from '@/services/ant-design-pro/api';
import UserComp from '@/components/UserComp';

import { useState, useEffect, useMemo } from 'react';
import { useRequest } from 'ahooks';

import styles from './index.less';

import classNames from 'classnames';

const cx = classNames.bind(styles);

const AuthorizatonList = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [form] = Form.useForm();

  const [page, setPage] = useState(1);
  //page limit
  const [limit] = useState(10);

  const { data, loading, run } = useRequest(() =>
    getaccountlist({
      page: page,
      limit,
    }),
  );

  useEffect(() => {
    run();
  }, [run, page]);
  //缓存
  const { list, paging } = useMemo(() => data?.data || {}, [data]);

  const isLoading = loading;

  const showModal = () => {
    setIsModalOpen(true);
  };
  //授权
  const handleOk = async () => {
    let authtype;
    const likeAuth = form.getFieldValue('likeAuth');
    const retwAuth = form.getFieldValue('retwAuth');
    if (likeAuth && retwAuth) {
      authtype = 3;
    } else if (retwAuth) {
      authtype = 2;
    } else if (likeAuth) {
      authtype = 1;
    }
    if (authtype) {
      window.open(
        `https://twitterresearchapi.visioncap.io/auth/jumpoauthpage?auth_type=${authtype}`,
      );
      setIsModalOpen(false);
      form.resetFields();
    } else {
      message.error('请选择需要授权的权限');
    }
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  // const valueEnum = {
  //   0: 'close',
  //   1: 'running',
  // };

  const columns = useMemo(
    () => [
      {
        title: '名称',
        dataIndex: 'name',
        align: 'center',
        key: 'name',
        width: 300,
        render: (name, { profile_image_url, account }) => (
          <UserComp name={name} profileImageUrl={profile_image_url} userAccount={account} />
        ),
      },
      {
        title: '点赞权限',
        align: 'center',
        dataIndex: 'auth_type',
        key: 'auth_type',
        render: (authType) => {
          let text = '未授权';
          if (authType !== 2) {
            text = '已授权';
          }
          return <div style={{ color: authType !== 2 ? 'green' : 'red' }}>{text}</div>;
        },
      },
      {
        title: '转发权限',
        align: 'center',
        key: 'auth_type',
        dataIndex: 'auth_type',
        render: (authType) => {
          let text = '未授权';
          if (authType !== 1) {
            text = '已授权';
          }
          return (
            <div
              style={{
                color: authType !== 1 ? 'green' : 'red',
              }}
            >
              {text}
            </div>
          );
        },
      },
    ],
    [],
  );

  return (
    <PageContainer
      header={{
        style: { backgroundColor: 'white', height: '90px' },
        extra: [
          // eslint-disable-next-line react/jsx-key
          <Button onClick={showModal} type="primary">
            账号授权
          </Button>,
        ],
      }}
    >
      <Modal title="账号授权" open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
        <Divider />
        <Form form={form} style={{ marginTop: '70px', marginBottom: '50px' }}>
          <Row>
            <Form.Item name="likeAuth" valuePropName="checked">
              <Checkbox>点赞权限</Checkbox>
            </Form.Item>
            <Form.Item name="retwAuth" valuePropName="checked">
              <Checkbox>转发权限</Checkbox>
            </Form.Item>
          </Row>
        </Form>
        <Divider />
      </Modal>
      <div className={cx('container')}>
        <div className={`${cx('comTablePro', 'listView')}`}>
          <ProTable
            rowKey="user_id"
            pagination={{ total: paging?.amount || 0, pageSize: limit, onChange: setPage }}
            columns={columns}
            options={false}
            search={false}
            dataSource={list || []}
            loading={isLoading}
          />
        </div>
      </div>
    </PageContainer>
  );
};

export default AuthorizatonList;
