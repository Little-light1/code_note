import { PageContainer } from '@ant-design/pro-components';
import { Input, Button, message, Spin } from 'antd';
import { onekeylikeorretweet } from '@/services/ant-design-pro/api';
import React, { useState, useEffect } from 'react';

import classNames from 'classnames/bind';
import styles from './index.less';
const cx = classNames.bind(styles);

const TwitterPromotion = () => {
  const [twUrl, setTwUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const onekeylikeorretweetFn = async (auth_type) => {
    setLoading(true);
    const { code, data, msg } = await onekeylikeorretweet({ tweet_url: twUrl, auth_type });
    const text = auth_type === 1 ? '点赞' : '转发';
    if (code === 200) {
      const { fail, success } = data;
      if (fail === 1 && success === 0) {
        message.error(`${text}失败`);
      }
      if (fail === 0 && success > 1) {
        message.success(`${text}成功`);
      }
    } else {
      message.error(msg);
    }
    setLoading(false);
  };

  return (
    <Spin spinning={loading}>
      <PageContainer header={{ style: { backgroundColor: 'white', height: '120px' } }}>
        <div className={cx('desc')}>
          这是Vision Infinity
          内部推文推广工具，你只需要将需要推广的链接复制到下方输入框中，点击【点赞】【转发】即可
        </div>
        <div className={cx('container')}>
          <div className={cx('contentBox')}>
            <div className={cx('inputBox')}>
              <span>推文地址：</span>
              <Input
                style={{ width: '450px' }}
                placeholder="推文地址"
                onChange={(tw) => {
                  setTwUrl(tw.target.value);
                }}
              />
            </div>
            <div className={cx('linkText')}>
              链接格式：https://twitter.com/punk2898/status/1607636750553460738
            </div>
            <div className={styles.btnBox}>
              <Button
                type="primary"
                onClick={() => {
                  onekeylikeorretweetFn(1);
                }}
              >
                点赞推文
              </Button>
              <Button
                type="primary"
                onClick={() => {
                  onekeylikeorretweetFn(2);
                }}
              >
                转发推文
              </Button>
            </div>
          </div>
        </div>
      </PageContainer>
    </Spin>
  );
};

export default TwitterPromotion;
