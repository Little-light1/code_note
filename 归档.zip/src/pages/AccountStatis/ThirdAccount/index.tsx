// 第三方账号统计
import type { ProColumns } from '@ant-design/pro-components';
import { PageContainer, ProTable } from '@ant-design/pro-components'; // '@ant-design/pro-table';
import { Button, DatePicker, Form, Input, message, Modal } from 'antd';

import classNames from 'classnames/bind';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import {
  addtwitteruser,
  deltwitteruser,
  getThirdStatistical,
  getThirdStatisticalInTime,
} from '@/services/ant-design-pro/api';

import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc';

import { useRequest } from 'ahooks';

import UserComp from '@/components/UserComp';

import styles from './index.less';

const cx = classNames.bind(styles);

dayjs.extend(utc);

const oneDay = 24 * 60 * 60;
//const oneWeek = oneDay * 7;
//const oneMonth = oneDay * 30;
// let endTime = dayjs.utc().unix(); // 当前时间戳
// const todayDate = dayjs().date(); // 获取今天几号
// const today930 = dayjs().date(todayDate).hour(9).minute(30).second(0).unix(); // 当天的九点半的时间戳
// const dateFormat = dayjs.unix(currentTime).format('YYYY-MM-DD HH:mm:ss');
// if (endTime < today930) {
//   endTime = dayjs.utc().unix() - oneDay; // 获取前一天时间戳
// }
const endTime = dayjs().unix();
export const CountBox = ({ list }: { list: any }) => {
  return (
    <div className={cx('countBox')}>
      <div className={cx('itemBox')}>
        <span>{'粉丝总量'}</span>
        <div>{list?.['follow_count'].toLocaleString()}</div>
      </div>
      <div className={cx('itemBox')}>
        <span>{'粉丝变化'}</span>
        <div>{list?.['follow_change'].toLocaleString()}</div>
      </div>
      <div className={cx('itemBox')}>
        <span>{'涨粉率'}</span>
        <div>{Number(list?.['increase_follow_rate']).toFixed(2)}%</div>
      </div>
      <div className={cx('itemBox')}>
        <span>{'未来 1 个月估算'}</span>
        <div>
          {Math.floor(
            Math.pow(1 + Number(list?.['increase_follow_rate']) / 100, 30) * list?.['follow_count'],
          ).toLocaleString()}
        </div>
      </div>
      <div className={cx('itemBox')}>
        <span>{'未来 3 个月估算'}</span>
        <div>
          {Math.floor(
            Math.pow(1 + Number(list?.['increase_follow_rate']) / 100, 90) * list?.['follow_count'],
          ).toLocaleString()}
        </div>
      </div>
      <div className={cx('itemBox', 'borderRight')}>
        <span>{'未来 6 个月估算'}</span>
        <div>
          {Math.floor(
            Math.pow(1 + Number(list?.['increase_follow_rate']) / 100, 180) *
              list?.['follow_count'],
          ).toLocaleString()}
        </div>
      </div>
    </div>
  );
};

const ThirdAccount = () => {
  const { RangePicker } = DatePicker;

  const [isModalOpen, steIsModalOpen] = useState(false); // 添加用户弹框
  const [startTimeParam, setStartTimeParam] = useState(endTime - oneDay);
  const [endTimeParam, setEndTimeParam] = useState(endTime);
  const [isToday, setIsToday] = useState(false);

  const inputRef = useRef<HTMLInputElement>();

  const [page, setPage] = useState(1);
  const [limit] = useState(50);

  const { data, loading, run } = useRequest(() => {
    if (isToday) {
      return getThirdStatisticalInTime({
        page: page,
        limit,
      });
    } else {
      return getThirdStatistical({
        page: page,
        limit,
        start_time: startTimeParam,
        end_time: endTimeParam,
      });
    }
  });

  useEffect(() => {
    run();
  }, [run, page, startTimeParam, endTimeParam, isToday]);

  const { list, paging } = useMemo(() => data?.data || {}, [data]);

  const {
    data: dropData,
    run: dropUser,
    loading: dropLoading,
  } = useRequest(deltwitteruser, { manual: true });

  useEffect(() => {
    if (dropData?.data?.msg === 'success') {
      message.success('删除成功！');
      setPage((page) => {
        if (page !== 1) {
          run();
        }

        return 1;
      });
      run();
    }
  }, [dropData]);

  const {
    data: addData,
    run: addUser,
    loading: addLoading,
  } = useRequest(addtwitteruser, { manual: true });

  useEffect(() => {
    if (addData?.data?.msg === 'success') {
      message.success('添加成功！');
      setPage((page) => {
        if (page !== 1) {
          run();
        }

        return 1;
      });

      steIsModalOpen(false);

      run();
    }
  }, [addData]);

  const isLoading = loading || dropLoading || addLoading;

  const columns = useMemo(
    () =>
      [
        {
          title: '名称',
          dataIndex: 'user_name',
          key: 'user_name',
          width: 240,
          render: (
            name: string,
            {
              profile_image_url,
              user_account,
            }: { profile_image_url: string; user_account: string },
          ) => (
            <UserComp name={name} profileImageUrl={profile_image_url} userAccount={user_account} />
          ),
        },
        {
          title: '粉丝数量',
          align: 'center',
          dataIndex: 'follow_count',
          key: 'follow_count',
          render: (follow_count: number) => {
            return follow_count.toLocaleString();
          },
        },
        {
          title: '粉丝变化',
          align: 'center',
          key: 'follow_change',
          dataIndex: 'follow_change',
          render: (follow_change: number) => {
            const isNegative = follow_change < 0;
            return (
              <div style={{ color: isNegative ? 'red' : '#3eac4e' }}>
                {isNegative ? follow_change : '+' + follow_change}
              </div>
            );
          },
        },

        {
          title: '涨粉率',
          align: 'center',
          dataIndex: 'increase_follow_rate',
          key: 'increase_follow_rate',
          render: (increase_follow_rate: number) => (
            <div>{Number(increase_follow_rate).toFixed(2)}%</div>
          ),
        },
        {
          title: '未来 1 个月估算',
          align: 'center',
          dataIndex: 'one_month',
          key: 'one_month',
          render: (text, record) => {
            const value = Math.floor(
              Math.pow(1 + Number(record.increase_follow_rate) / 100, 30) * record.follow_count,
            ).toLocaleString();
            return value;
          },
        },

        {
          title: '未来 3 个月估算',
          align: 'center',
          dataIndex: 'three_month',
          key: 'three_month',
          render: (text, record) => {
            const value = Math.floor(
              Math.pow(1 + Number(record.increase_follow_rate) / 100, 90) * record.follow_count,
            ).toLocaleString();
            return value;
          },
        },

        {
          title: '未来 6 个月估算',
          align: 'center',
          dataIndex: 'six_month',
          key: 'six_month',
          render: (text, record) => {
            const value = Math.floor(
              Math.pow(1 + Number(record.increase_follow_rate) / 100, 180) * record.follow_count,
            ).toLocaleString();
            return value;
          },
        },
        {
          align: 'center',
          width: 100,
          render: ({ user_id }) => {
            return (
              <Button type="link" danger onClick={() => dropUser({ user_id })}>
                删除
              </Button>
            );
          },
        },
      ] as ProColumns<API.UserDataList>[],
    [dropUser],
  );

  // 弹框确认
  const handleOk = useCallback(() => {
    const account = inputRef?.current?.input?.value;
    if (!account) {
      return message.info('account 不能为空');
    }

    addUser({ account });
  }, [addUser]);

  // 弹框取消
  const handleCancel = useCallback(() => {
    steIsModalOpen(false);
  }, []);

  const openAddDialog = useCallback(() => {
    steIsModalOpen(true);
  }, []);

  //const riqiBtns = ['日', '周', '月'];

  return (
    <PageContainer header={{ style: { backgroundColor: 'white', height: '90px' } }}>
      <div className={cx('container')}>
        <CountBox list={list} />

        <div className={cx('tableTitle')}>
          <div className={cx('title')}>Twitter 列表</div>
          <div className={cx('btnsBox')}>
            <Button style={{ marginRight: '20px' }} onClick={() => setIsToday(true)}>
              今日数据
            </Button>
            <span>选择日期：</span>
            <RangePicker
              onChange={(date, dateString) => {
                const start = dayjs(dateString[0]).unix();
                const end = dayjs(dateString[1]).unix();
                setStartTimeParam(start);
                setEndTimeParam(end);
                setIsToday(false);
              }}
            />
          </div>
        </div>
        <div className={cx('addBox')} onClick={openAddDialog}>
          <div className={cx('addItem')}>
            <Button type="dashed" block>
              + 添加
            </Button>
          </div>
        </div>

        <div className={`comTablePro ${cx('listView')}`}>
          <ProTable
            rowKey="user_id"
            pagination={{ total: paging?.amount || 0, pageSize: limit, onChange: setPage }}
            columns={columns}
            options={false}
            search={false}
            dataSource={list?.user_data_list || []}
            loading={isLoading}
          />
        </div>
      </div>
      {isModalOpen && (
        <Modal title="添加账户" open onOk={handleOk} onCancel={handleCancel}>
          <Form labelCol={{ span: 8 }} wrapperCol={{ span: 16 }}>
            <Form.Item
              label="Account"
              name="username"
              rules={[{ required: true, message: 'Please input your username!' }]}
            >
              <Input ref={inputRef} />
            </Form.Item>
          </Form>
        </Modal>
      )}
    </PageContainer>
  );
};

export default ThirdAccount;
