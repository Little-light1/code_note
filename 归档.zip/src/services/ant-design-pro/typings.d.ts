// @ts-ignore
/* eslint-disable */

declare namespace API {
  type CurrentUser = {
    name?: string;
    avatar?: string;
    token?: string;
    // userid?: string;
    // email?: string;
    // signature?: string;
    // title?: string;
    // group?: string;
    // tags?: { key?: string; label?: string }[];
    // notifyCount?: number;
    // unreadCount?: number;
    // country?: string;
    // access?: string;
    // geographic?: {
    //   province?: { label?: string; key?: string };
    //   city?: { label?: string; key?: string };
    // };
    // address?: string;
    // phone?: string;
  };

  type LoginResult = {
    code?: number;
    data?: {
      token?: string;
    };
  };

  type PageParams = {
    current?: number;
    pageSize?: number;
  };

  type RuleListItem = {
    key?: number;
    disabled?: boolean;
    href?: string;
    avatar?: string;
    name?: string;
    owner?: string;
    desc?: string;
    callNo?: number;
    status?: number;
    updatedAt?: string;
    createdAt?: string;
    progress?: number;
  };

  type RuleList = {
    data?: RuleListItem[];
    /** 列表的内容总数 */
    total?: number;
    success?: boolean;
  };

  type FakeCaptcha = {
    code?: number;
    status?: string;
  };

  type LoginParams = {
    username?: string;
    password?: string;
  };

  type AccountStaticParams = {
    user_type?: number;
    page: number;
    limit: number;
    start_time?: number;
    end_time?: number;
  };

  type UserDataList = {
    follow_change: number;
    follow_count: number;
    increase_follow_rate: string;
    like_count: number;
    like_follow_rate: string;
    profile_image_url: string;
    reply_count: number;
    retweet_count: number;
    tweet_count: number;
    user_account: string;
    user_id: string;
    user_name: string;
  }[];

  type AccountStaticList = {
    follow_count: number;
    follow_change: number;
    like_count: number;
    reply_count: number;
    re_tweet_count: number;
    increase_follow_rate: string;
    user_data_list: UserDataList;
  };

  type AccountStaticResult = {
    code?: number;
    data?: {
      list?: AccountStaticList;
      paging?: {
        amount: number;
        page: number;
        limit: number;
      };
    };
    msg: string;
  };

  type GptcResult = {
    code?: number;
    data?: {
      reuslt?: string
    };
    msg: string;
  };

  type ErrorResponse = {
    /** 业务约定的错误码 */
    errorCode: string;
    /** 业务上的错误信息 */
    errorMessage?: string;
    /** 业务上的请求是否成功 */
    success?: boolean;
  };

  type NoticeIconList = {
    data?: NoticeIconItem[];
    /** 列表的内容总数 */
    total?: number;
    success?: boolean;
  };

  type NoticeIconItemType = 'notification' | 'message' | 'event';

  type NoticeIconItem = {
    id?: string;
    extra?: string;
    key?: string;
    read?: boolean;
    avatar?: string;
    title?: string;
    status?: string;
    datetime?: string;
    description?: string;
    type?: NoticeIconItemType;
  };

  type onekeylikeorretweetResult = {
    code: number;
    data: {
      fail: number;
      success: number;
      total: number;
    };
    msg: string;
  };
}
