// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';

import { SERVER } from '@/../config/proxy';
import { IS_LOCAL } from '@/utils/common';

const API = IS_LOCAL ? '/api' : SERVER;

/** 登录接口 POST /api/login/account */
export async function login(body: API.LoginParams) {
  return request<API.LoginResult>(`${API}/index/ctrllogin`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: body,
  });
}

/** 获取自有账号统计 */
export async function getSelfStatistical(body: API.AccountStaticParams) {
  return request<API.AccountStaticResult>(`${API}/security/admin/gettwitterstatistical`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
      user_type: 1,
    },
  });
}

/**获取实时账号统计 */
export async function getSelfStatisticalInTime(body: API.AccountStaticParams) {
  return request<API.AccountStaticResult>(`${API}/security/admin/gettwitterstatisticalintime`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
      user_type: 1,
    },
  });
}

/** 获取第三方账号统计 */
export async function getThirdStatistical(body: API.AccountStaticParams) {
  return request<API.AccountStaticResult>(`${API}/security/admin/gettwitterstatistical`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
      user_type: 2,
    },
  });
}

/**获取实时第三方账号统计 */
export async function getThirdStatisticalInTime(body: API.AccountStaticParams) {
  return request<API.AccountStaticResult>(`${API}/security/admin/gettwitterstatisticalintime`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
      user_type: 2,
    },
  });
}

/** 删除第三方账号 */
export async function deltwitteruser(body: any) {
  return request<API.AccountStaticResult>(`${API}/security/admin/deltwitteruser`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
    },
  });
}

/** 添加第三方账号 */
export async function addtwitteruser(body: any) {
  return request<API.AccountStaticResult>(`${API}/security/admin/addtwitteruser`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
      user_type: 2,
    },
  });
}
/** 添加自有账号 */
export async function addselftwitteruser(body: any) {
  return request<API.AccountStaticResult>(`${API}/security/admin/addtwitteruser`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
      user_type: 1,
    },
  });
}

// 一键点赞和转发
export async function onekeylikeorretweet(body: any) {
  return request<API.onekeylikeorretweetResult>(`${API}/security/admin/onekeylikeorretweet`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
    },
  });
}

// 获取账号列表
export async function getaccountlist(body: any) {
  return request<any>(`${API}/security/admin/getaccountlist`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
    },
  });
}

// 跳转twwiter页面授权
export async function jumpoauthpage(body: any) {
  return request<any>(`${API}/auth/jumpoauthpage`, {
    method: 'GET',
    params: { ...body },
  });
}

/**  */
export async function getContentFromChatgpt(body: { [name: string]: string }) {
  return request<API.GptcResult>(`${API}/security/admin/getcontentfromchatgpt`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
    },
  });
}

/* LLM 文件上传*/
export async function fileUpload(body: any) {
  return request<any>(`${API}/security/admin/uploadfile`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: body,
  });
}

/* 获取推文列表*/
export async function getTweetList(body: any) {
  return request<any>(`${API}/security/admin/gettweetlist`, {
    method: 'POST',
    headers: {
      'Content-Type': 'multipart/form-data',
    },
    data: {
      ...body,
      login_token: localStorage.getItem('login_token'),
    },
  });
}
